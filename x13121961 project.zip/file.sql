



--
-- Create schema bank
--

CREATE DATABASE IF NOT EXISTS bank;
USE bank;



-- SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
-- SET FOREIGN_KEY_CHECKS=0;

-- ---
-- Table 'account'
-- 
-- ---

DROP TABLE IF EXISTS `account`;
 
CREATE TABLE `account` (
  `account_id` INT(11) NOT NULL,
  `customer_id` INT(11) NOT NULL DEFAULT 0,
  `sort_code` INT(11) NULL DEFAULT NULL,
  `balance` DECIMAL(12) NULL DEFAULT NULL,
  PRIMARY KEY (`account_id`)
);

-- ---
-- Table 'customer'
-- 
-- ---

DROP TABLE IF EXISTS `customer`;
 
CREATE TABLE `customer` (
  `customer_id` INT(11) NOT NULL,
  `first_name` VARCHAR(45) NULL DEFAULT NULL,
  `last_name` VARCHAR(45) NULL DEFAULT NULL,
  `address` VARCHAR(90) NULL DEFAULT NULL,
  `email` VARCHAR(45) NULL DEFAULT NULL,
  `security_Key` INT(11) NULL DEFAULT NULL,
  PRIMARY KEY (`customer_id`)
);

-- ---
-- Table 'transaction'
-- 
-- ---

DROP TABLE IF EXISTS `transaction`;
 
CREATE TABLE `transaction` (
  `transaction_id` INT(11) NOT NULL,
  `type` VARCHAR(45) NOT NULL DEFAULT 'debit',
  `account_id` INT(11) NOT NULL,
  `date` DATE NOT NULL,
  `description` VARCHAR(45) NULL DEFAULT NULL,
  `amount` DECIMAL(12) NOT NULL DEFAULT 0,
  `newBalance` DECIMAL(12) NULL DEFAULT 0,
  PRIMARY KEY (`transaction_id`, `type`)
);

-- ---
-- Foreign Keys 
-- ---

ALTER TABLE `account` ADD FOREIGN KEY (customer_id) REFERENCES `customer` (`customer_id`);
ALTER TABLE `transaction` ADD FOREIGN KEY (account_id) REFERENCES `account` (`account_id`);

-- ---
-- Table Properties
-- ---

-- ALTER TABLE `account` ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
-- ALTER TABLE `customer` ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
-- ALTER TABLE `transaction` ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ---
-- Test Data
-- ---

-- INSERT INTO `account` (`account_id`,`customer_id`,`sort_code`,`balance`) VALUES
-- ('','','','');
-- INSERT INTO `customer` (`customer_id`,`first_name`,`last_name`,`address`,`email`,`securityKey`) VALUES
-- ('','','','','','');
-- INSERT INTO `transaction` (`transaction_id`,`type`,`account_id`,`date`,`description`,`amount`,`newBalance`) VALUES
-- ('','','','','','','');